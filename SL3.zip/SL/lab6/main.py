import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv("Antfile17.csv")
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

id3_model = DecisionTreeClassifier(criterion="entropy", random_state=42)
id3_model.fit(X_train, y_train)
y_pred_id3 = id3_model.predict(X_test)

print("\n=== ID3 Results (Entropy) ===")
print("Accuracy:", accuracy_score(y_test, y_pred_id3))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred_id3))
print("Classification Report:\n", classification_report(y_test, y_pred_id3))

plt.figure(figsize=(12, 6))
plot_tree(id3_model, filled=True, feature_names=X.columns, class_names=np.unique(y).astype(str))
plt.title("ID3 Decision Tree (Entropy)")
plt.show()

cart_model = DecisionTreeClassifier(criterion="gini", random_state=42)
cart_model.fit(X_train, y_train)
y_pred_cart = cart_model.predict(X_test)

print("\n=== CART Results (Gini) ===")
print("Accuracy:", accuracy_score(y_test, y_pred_cart))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred_cart))
print("Classification Report:\n", classification_report(y_test, y_pred_cart))

plt.figure(figsize=(12, 6))
plot_tree(cart_model, filled=True, feature_names=X.columns, class_names=np.unique(y).astype(str))
plt.title("CART Decision Tree (Gini)")
plt.show()
