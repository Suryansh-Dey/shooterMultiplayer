# ---------------------------------------------
# LAB 8 - Ensemble Learning on Antfile17 Dataset
# ---------------------------------------------
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier, AdaBoostClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt

# -------------------------------
# STEP 1: Load dataset
# -------------------------------
df = pd.read_csv("Antfile17.csv")

print("Dataset shape:", df.shape)
print("\nSample data:\n", df.head())

# -------------------------------
# STEP 2: Data preprocessing
# -------------------------------
# Encode categorical features to numeric if needed
label_encoders = {}
for col in df.columns:
    if df[col].dtype == 'object':
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
        label_encoders[col] = le

# Automatically detect target column (last column)
target_col = df.columns[-1]
print("\nDetected target column:", target_col)

X = df.drop(columns=[target_col])
y = df[target_col]

# -------------------------------
# STEP 3: Train-test split
# -------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -------------------------------
# STEP 4: Bagging Classifier
# -------------------------------
bag_model = BaggingClassifier(
    estimator=DecisionTreeClassifier(),
    n_estimators=10,
    random_state=42
)

bag_model.fit(X_train, y_train)
y_pred_bag = bag_model.predict(X_test)

print("\n=== BAGGING RESULTS ===")
bag_acc = accuracy_score(y_test, y_pred_bag)
print("Accuracy:", bag_acc)
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred_bag))
print("\nClassification Report:\n", classification_report(y_test, y_pred_bag))

# -------------------------------
# STEP 5: AdaBoost Classifier
# -------------------------------
ada_model = AdaBoostClassifier(
    estimator=DecisionTreeClassifier(max_depth=1),
    n_estimators=50,
    learning_rate=1.0,
    random_state=42
)

ada_model.fit(X_train, y_train)
y_pred_ada = ada_model.predict(X_test)

print("\n=== ADABOOST RESULTS ===")
ada_acc = accuracy_score(y_test, y_pred_ada)
print("Accuracy:", ada_acc)
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred_ada))
print("\nClassification Report:\n", classification_report(y_test, y_pred_ada))

# -------------------------------
# STEP 6: Compare Model Performance
# -------------------------------
print("\n=== MODEL COMPARISON ===")
print(f"Bagging Accuracy  : {bag_acc:.4f}")
print(f"AdaBoost Accuracy : {ada_acc:.4f}")

# -------------------------------
# STEP 7: Visualization
# -------------------------------
plt.figure(figsize=(6, 4))
plt.bar(["Bagging", "AdaBoost"], [bag_acc, ada_acc], color=['skyblue', 'salmon'])
plt.title("Model Accuracy Comparison")
plt.ylabel("Accuracy")
plt.ylim(0, 1)
plt.show()
