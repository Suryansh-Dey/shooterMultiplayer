import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
import seaborn as sns
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')

# 2. DATA PREPARATION
try:
    
    df = pd.read_csv('Antfile17.csv') 
    print("--- Dataset Loaded Successfully ---")

except FileNotFoundError:
    print("\nError: 'Antfile17.csv' not found. Please place it in the same directory.")
    exit()

# Set the correct target column name
target_column = 'bug' 

X = df.drop(target_column, axis=1)

y = df[target_column]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print(f"\nTraining set size: {X_train_scaled.shape[0]} samples")
print(f"Test set size: {X_test_scaled.shape[0]} samples\n")


# 3. MODEL TRAINING & EVALUATION LOOP
models = {
    'Linear Kernel': SVC(kernel='linear', random_state=42),
    'Polynomial Kernel': SVC(kernel='poly', random_state=42),
    'RBF Kernel': SVC(kernel='rbf', random_state=42),
    'Sigmoid Kernel': SVC(kernel='sigmoid', random_state=42)
}

summary_results = []

for name, model in models.items():
    print(f"================== Evaluating {name} ==================")
    
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    
    accuracy = accuracy_score(y_test, y_pred)
    print(f"\nAccuracy: {accuracy:.4f}")
    
    print("\nClassification Report:")
    report = classification_report(y_test, y_pred, target_names=['No Bug (0)', 'Bug (1)'])
    print(report)
    
    f1_class_0 = f1_score(y_test, y_pred, pos_label=0)
    f1_class_1 = f1_score(y_test, y_pred, pos_label=1)
    summary_results.append([name, accuracy, f1_class_0, f1_class_1])
    
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(7, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['No Bug', 'Bug'], 
                yticklabels=['No Bug', 'Bug'])
    plt.title(f'Confusion Matrix for {name}')
    plt.ylabel('Actual Label')
    plt.xlabel('Predicted Label')
    plt.show()
    print("\n")

# 4. FINAL SUMMARY
print("================== Final Model Comparison ==================")
summary_df = pd.DataFrame(summary_results, columns=['Kernel', 'Accuracy', 'F1-Score (No Bug)', 'F1-Score (Bug)'])
summary_df = summary_df.set_index('Kernel')
print(summary_df)
print("\n--- End of Lab ---")