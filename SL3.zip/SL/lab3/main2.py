import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
from imblearn.combine import SMOTETomek
import seaborn as sns
import matplotlib.pyplot as plt
import os

# 1. Load the dataset
df = pd.read_csv('antfile17.csv')

# Assuming 'bug' is the target column
target_col = 'bug'

# Check imbalance
bug_counts = df[target_col].value_counts()
print("Bug counts:\n", bug_counts)

minority = bug_counts.min()
majority = bug_counts.max()
imbalance_ratio = minority / majority
print(f"Imbalance ratio: {imbalance_ratio:.2f}")

# 2. Function to handle resampling
def chooseMode(imbalance_ratio, mode):
    X = df.drop(target_col, axis=1)
    y = df[target_col]

    if mode == "50-50":
        print("Data is imbalanced. Applying SMOTE Tomek for 50-50 balance.")
        smt = SMOTETomek(sampling_strategy='auto', random_state=42)
        X_res, y_res = smt.fit_resample(X, y)
        print("Balanced counts (50-50):\n", pd.Series(y_res).value_counts())

    elif mode == "double":
        print("Doubling the balanced data.")
        smt = SMOTETomek(sampling_strategy={0:10000, 1:10000}, random_state=42)
        X_res, y_res = smt.fit_resample(X, y)
        print("Doubled counts:\n", pd.Series(y_res).value_counts())

    else:
        X_res = X.values
        y_res = y.values

    return X_res, y_res

# 3. Function to visualize results
def visualize(mode, imbalance_ratio):
    X_res, y_res = chooseMode(imbalance_ratio, mode)

    # Split data into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(
        X_res, y_res, test_size=0.2, random_state=42, stratify=y_res
    )

    # Scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Logistic Regression
    model = LogisticRegression()
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    print(f"Confusion Matrix ({mode}):\n", cm)

    # Confusion matrix heatmap
    plt.figure(figsize=(6, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.title(f'Confusion Matrix Heatmap - {mode}')
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.savefig(f'confusion_matrix_{mode}.png')
    plt.show()

    # Classification report
    print(f"Classification Report ({mode}):\n", classification_report(y_test, y_pred))

    # ROC Curve and AUC
    fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
    roc_auc = auc(fpr, tpr)
    plt.figure(figsize=(6, 4))
    plt.plot(fpr, tpr, label=f'ROC curve (AUC = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(f'Receiver Operating Characteristic (ROC) - {mode}')
    plt.legend(loc='lower right')

    # Ensure save directory exists
    save_dir = './plots'
    os.makedirs(save_dir, exist_ok=True)
    plt.savefig(os.path.join(save_dir, f'roc_curve_{mode}.png'))
    plt.show()

    print(f"AUC Score ({mode}): {roc_auc:.2f}")

# 4. Main function
def main():
    visualize("50-50", imbalance_ratio)
    visualize("double", imbalance_ratio)

if __name__ == "__main__":
    main()
