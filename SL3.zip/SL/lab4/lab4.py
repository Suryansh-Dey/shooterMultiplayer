# -------------------------
# DATASET (from the question)
# -------------------------
data = [
    {"age": "youth", "income": "high", "student": "no",  "credit": "fair", "class": "no"},
    {"age": "youth", "income": "high", "student": "no",  "credit": "excellent", "class": "no"},
    {"age": "middle_aged", "income": "high", "student": "no",  "credit": "fair",   "class": "yes"},
    {"age": "senior", "income": "medium", "student": "no",  "credit": "fair",      "class": "yes"},
    {"age": "senior", "income": "low", "student": "yes", "credit": "fair",      "class": "yes"},
    {"age": "senior", "income": "low", "student": "yes", "credit": "excellent", "class": "no"},
    {"age": "middle_aged", "income": "low", "student": "yes", "credit": "excellent", "class": "yes"},
    {"age": "youth", "income": "medium", "student": "no",  "credit": "fair",      "class": "no"},
    {"age": "youth", "income": "low", "student": "yes", "credit": "fair",      "class": "yes"},
    {"age": "senior", "income": "medium", "student": "yes", "credit": "fair",      "class": "yes"},
    {"age": "youth", "income": "medium", "student": "yes", "credit": "excellent", "class": "yes"},
    {"age": "middle_aged", "income": "medium", "student": "no",  "credit": "excellent", "class": "yes"},
    {"age": "middle_aged", "income": "high", "student": "yes", "credit": "fair",      "class": "yes"},
    {"age": "senior", "income": "medium", "student": "no",  "credit": "excellent", "class": "no"},
]

attributes = ["age", "income", "student", "credit"]


# -------------------------
# STEP 1: Count priors
# -------------------------
total_yes = sum(1 for row in data if row["class"] == "yes")
total_no  = sum(1 for row in data if row["class"] == "no")
total     = len(data)

print("Priors:")
print("P(YES) =", total_yes, "/", total, "=", total_yes/total)
print("P(NO)  =", total_no, "/", total, "=", total_no/total)
print()


# -------------------------
# STEP 2: Build frequency tables
# -------------------------
freq = {attr: {} for attr in attributes}

for attr in attributes:
    for row in data:
        val = row[attr]
        cls = row["class"]

        if val not in freq[attr]:
            freq[attr][val] = {"yes": 0, "no": 0}

        freq[attr][val][cls] += 1

# Show frequency tables
print("Frequency tables (counts inside YES/NO baskets):")
for attr in attributes:
    print("\nAttribute:", attr)
    for val, counts in freq[attr].items():
        print("  ", val, ":", counts)


# -------------------------
# STEP 3: Convert to probabilities
# -------------------------
probs = {attr: {} for attr in attributes}

for attr in attributes:
    for val, counts in freq[attr].items():
        probs[attr][val] = {
            "yes": counts["yes"] / total_yes if total_yes > 0 else 0,
            "no": counts["no"] / total_no if total_no > 0 else 0
        }

# Show conditional probabilities
print("\nConditional probabilities P(attribute=value | class):")
for attr in attributes:
    print("\nAttribute:", attr)
    for val, p in probs[attr].items():
        print("  ", val, ":", p)


# -------------------------
# STEP 4: Naive Bayes classifier
# -------------------------
def classify(example):
    # priors
    p_yes = total_yes / total
    p_no  = total_no / total

    score_yes = p_yes
    score_no  = p_no

    print("\nExample to classify:", example)

    # multiply feature probabilities
    for attr in attributes:
        val = example[attr]
        py = probs[attr].get(val, {"yes":0,"no":0})["yes"]
        pn = probs[attr].get(val, {"yes":0,"no":0})["no"]

        score_yes *= py
        score_no  *= pn

        print(f"  P({attr}={val} | YES) = {py},  P({attr}={val} | NO) = {pn}")

    print("  Final YES score =", score_yes)
    print("  Final NO  score =", score_no)

    if score_yes > score_no:
        print("  Decision: YES (buys computer)")
        return "yes"
    else:
        print("  Decision: NO (does not buy)")
        return "no"


# -------------------------
# STEP 5: Test X1 and X2
# -------------------------
X1 = {"age": "youth", "income": "medium", "student": "yes", "credit": "fair"}
X2 = {"age": "senior", "income": "high", "student": "yes", "credit": "fair"}

print("\n\n--- Classifying X1 ---")
classify(X1)

print("\n\n--- Classifying X2 ---")
classify(X2)
