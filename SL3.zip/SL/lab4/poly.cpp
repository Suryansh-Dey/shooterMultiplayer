#include<iostream>
using namespace std;
class person
{
    public:
    virtual void introduce()
    {
        cout<<"i am a person"<<endl;
    }
};
class student:public person
{
    public:
    void introduce() override
    {
        cout<<"i am a student"<<endl;
    }
};
int main()
{
    person *p=new person();
    p->introduce();
    
}