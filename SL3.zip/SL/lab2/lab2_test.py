import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


df1=pd.read_csv("lab2/lrdata_1.csv")
df2=pd.read_csv("lab2/lrdata_2.csv")
df3=pd.read_csv("lab2/lrdata_3.csv")

