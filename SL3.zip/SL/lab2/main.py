import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df1 = pd.read_csv("lrdata_1.csv")
df2 = pd.read_csv("lrdata_2.csv")
df3 = pd.read_csv("lrdata_3.csv")

def gradient_descent(X, y, theta, alpha, iterations):
    m = len(y)
    losses = []
    X = np.c_[np.ones((m, 1)), X]
    for _ in range(iterations):
        predictions = X.dot(theta)
        errors = predictions - y
        gradient = (1/m) * X.T.dot(errors)
        theta -= alpha * gradient
        loss = (1/(2*m)) * np.sum(errors**2)
        losses.append(loss)
    return theta, losses

# apply gradient descent to df1
X1 = df1['X'].values
y1 = df1['y'].values
theta1 = np.random.rand(2)
alpha1 = 0.01
iterations1 = 100
theta1, losses1 = gradient_descent(X1, y1, theta1, alpha1, iterations1)

# Plotting the data for df1
plt.figure(figsize=(12, 5))
plt.plot(range(len(losses1)), losses1,color='green', label='Loss over Iterations')
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss Function Over Iterations for df1')
plt.legend()
plt.show()

# apply gradient descent to df2
X2 = df2['X'].values
y2 = df2['y'].values
theta2 = np.random.rand(2)
alpha2 = 0.01
iterations2 = 100
theta2, losses2 = gradient_descent(X2, y2, theta2, alpha2, iterations2)

# Plotting the data for df2
plt.figure(figsize=(12, 5))
plt.plot(range(len(losses2)), losses2,color='red',label='Loss over Iterations')
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss Function Over Iterations for df2')
plt.legend()
plt.show()

# apply gradient descent to df3
X3 = df3['X'].values
y3 = df3['y'].values
theta3 = np.random.rand(2)
alpha3 = 0.01
iterations3 = 100
theta3, losses3 = gradient_descent(X3, y3, theta3, alpha3, iterations3)

# Plotting the data for df3
plt.figure(figsize=(12, 5))
plt.plot(range(len(losses3)), losses3, color='blue',label='Loss over Iterations')
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.title('Loss Function Over Iterations for df3')
plt.legend()
plt.show()
