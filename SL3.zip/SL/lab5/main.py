import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelBinarizer
from sklearn.metrics import confusion_matrix, classification_report, roc_auc_score, roc_curve
import seaborn as sns
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# -------------------------
# Load and preprocess data
# -------------------------
iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

lb = LabelBinarizer()
y_train = lb.fit_transform(y_train)
y_test = lb.transform(y_test)

# -------------------------
# Function to build model
# -------------------------
def build_model(layers, initializer):
    model = Sequential()
    model.add(Dense(layers[0], input_dim=4, activation='relu', kernel_initializer=initializer))
    for units in layers[1:]:
        model.add(Dense(units, activation='relu', kernel_initializer=initializer))
    model.add(Dense(3, activation='softmax', kernel_initializer=initializer))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

# -------------------------
# Configurations to test
# -------------------------
configs = [
    ([5], 'he_normal'),             # 1 hidden layer
    ([10, 8], 'glorot_uniform'),    # 2 hidden layers
    ([16, 12, 8], 'he_uniform'),    # 3 hidden layers
]

results = []

# -------------------------
# Train & evaluate models
# -------------------------
for layers, init in configs:
    print(f"\n========== Model: layers={layers}, initializer={init} ==========")
    model = build_model(layers, init)
    history = model.fit(X_train, y_train, epochs=50, batch_size=5, verbose=0)

    train_loss, train_acc = model.evaluate(X_train, y_train, verbose=0)
    test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)

    print(f"Train Accuracy: {train_acc:.4f}")
    print(f"Test Accuracy: {test_acc:.4f}")

    # Predictions
    y_pred = model.predict(X_test)
    y_pred_classes = np.argmax(y_pred, axis=1)
    y_true = np.argmax(y_test, axis=1)

    # Confusion Matrix
    cm = confusion_matrix(y_true, y_pred_classes)
    print("Confusion Matrix:\n", cm)

    plt.figure(figsize=(6, 4))
    sns.heatmap(cm, annot=True, cmap="Blues", fmt="d",
                xticklabels=iris.target_names,
                yticklabels=iris.target_names)
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title(f"Confusion Matrix - {layers}, {init}")
    plt.show()

    # Classification Report
    print("\nClassification Report:\n",
          classification_report(y_true, y_pred_classes, target_names=iris.target_names))

    # ROC Curve & AUC
    fpr, tpr, roc_auc = {}, {}, {}
    for i in range(3):
        fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_pred[:, i])
        roc_auc[i] = roc_auc_score(y_test[:, i], y_pred[:, i])

    plt.figure(figsize=(6, 4))
    for i in range(3):
        plt.plot(fpr[i], tpr[i], label=f"{iris.target_names[i]} (AUC = {roc_auc[i]:.2f})")

    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title(f"ROC Curve - {layers}, {init}")
    plt.legend()
    plt.show()

    avg_auc = np.mean(list(roc_auc.values()))
    print("Average AUC Score:", avg_auc)

    results.append({
        "layers": layers,
        "initializer": init,
        "train_acc": train_acc,
        "test_acc": test_acc,
        "avg_auc": avg_auc
    })

# -------------------------
# Final Comparison Table
# -------------------------
results_df = pd.DataFrame(results)
print("\n==== Final Comparison ====\n")
print(results_df)
