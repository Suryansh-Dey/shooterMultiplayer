import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# --- Read data ---
df = pd.read_excel("lab1\housing.xlsx")

# --- Convert yes/no columns to 1/0 ---
cols = ['mainroad', 'guestroom', 'basement', 'hotwaterheating', 'airconditioning']

replace_dicts = {
    'mainroad': {'yes': 1, 'no': 0},
    'guestroom': {'yes': 1, 'no': 0},
    'basement': {'yes': 1, 'no': 0},
    'hotwaterheating': {'yes': 1, 'no': 0, 'not': 0},
    'airconditioning': {'yes': 1, 'no': 0}
}

for col in cols:
    df[col] = df[col].replace(replace_dicts[col]).astype(int)

# --- One-hot encode 'furnishingstatus' ---
furnishing_status = df['furnishingstatus'].unique()
for status in furnishing_status:
    df[status] = (df['furnishingstatus'] == status).astype(int)

df.drop(columns=['furnishingstatus'], inplace=True)

# --- Feature (X) and target (Y) ---
Y = df['price']
X = df.drop(columns=['price'])

# --- Add intercept column ---
X['intercept'] = 1

# --- Custom train-test split function ---
def train_test_split(X, Y, test_size=0.2):
    np.random.seed(42)
    n = len(X)
    test_count = int(n * test_size)
    indices = np.arange(n)
    np.random.shuffle(indices)

    test_idx = indices[:test_count]
    train_idx = indices[test_count:]

    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    Y_train, Y_test = Y.iloc[train_idx], Y.iloc[test_idx]

    return X_train, X_test, Y_train, Y_test

# --- Split the data ---
x_train, x_test, y_train, y_test = train_test_split(X, Y, 0.2)

# --- Ensure test columns match train columns ---
x_test = x_test[x_train.columns]

# --- Compute weights using Normal Equation ---
# w = (X^T * X)^(-1) * X^T * y
weight = np.linalg.pinv(x_train) @ y_train

# --- Predict ---
y_predict = x_test @ weight

# --- Evaluation metrics ---
mse = np.mean((y_predict - y_test) ** 2)
rss = np.sum((y_predict - y_test) ** 2)

print("Weights (including intercept):\n", weight)
print("Mean Squared Error:", mse)
print("Residual Sum of Squares:", rss)

# --- Plot: Actual vs Predicted ---
plt.figure(figsize=(10, 6))
X_area = x_test['area']

plt.scatter(X_area, y_test, color='black', label='Actual')
plt.scatter(X_area, y_predict, color='red', label='Predicted')

plt.xlabel('Area (sq.ft)')
plt.ylabel('Price')
plt.title("Price Prediction: Actual vs Predicted")
plt.legend()
plt.show()
