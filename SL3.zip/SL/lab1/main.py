import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# --- Read data ---
data = pd.read_excel("housing.xlsx")

# --- Convert yes/no columns to 1/0 ---
cols = ['mainroad', 'guestroom', 'basement', 'hotwaterheating', 'airconditioning']
replace_dicts = {
    'mainroad': {'yes':1,'no':0},
    'guestroom': {'yes':1,'no':0},
    'basement': {'yes':1,'no':0},
    'hotwaterheating': {'yes':1,'no':0,'not':0},
    'airconditioning': {'yes':1,'no':0}
}

pd.set_option('future.no_silent_downcasting', True)  # suppress FutureWarning

for col in cols:
    data[col] = data[col].replace(replace_dicts[col]).astype(int)

# --- One-hot encode 'furnishingstatus' ---
furnishing_status = data['furnishingstatus'].unique()
for status in furnishing_status:
    data[status] = (data['furnishingstatus'] == status).astype(int)
data.drop(columns=['furnishingstatus'], inplace=True)

# --- Features and target ---
Y = data['price']
X = data.drop(columns=['price'])

# --- Add intercept column BEFORE splitting ---
X['intercept'] = 1

# --- Train-test split ---
def train_test_split(X, Y, test_size=0.2):
    np.random.seed(42)
    n = len(X)
    test_count = int(n * test_size)
    indices = np.arange(n)
    np.random.shuffle(indices)
    
    test_idx = indices[:test_count]
    train_idx = indices[test_count:]
    
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    Y_train, Y_test = Y.iloc[train_idx], Y.iloc[test_idx]
    
    return X_train, X_test, Y_train, Y_test

x_train, x_test, y_train, y_test = train_test_split(X, Y, 0.2)

# --- Ensure test columns match train columns ---
x_test = x_test[x_train.columns]

# --- Linear regression using pseudo-inverse ---
weight = np.linalg.pinv(x_train) @ y_train

# --- Prediction ---
y_predict = x_test @ weight

# --- Results ---
print("Weights (including intercept):\n", weight)
print("MEAN squared error:", np.mean((y_predict - y_test)**2))
print("Residual sum of squares:", np.sum((y_predict - y_test)**2))

# --- Plot ---
plt.figure(figsize=(10,6))
X_area = x_test['area']
plt.scatter(X_area, y_test, color='black', label='actual')
plt.scatter(X_area, y_predict, color='red', label='predicted')
plt.xlabel('Area (sq.ft)')
plt.ylabel('Price')
plt.title("Price prediction: Actual vs Predicted")
plt.legend()
plt.show()
